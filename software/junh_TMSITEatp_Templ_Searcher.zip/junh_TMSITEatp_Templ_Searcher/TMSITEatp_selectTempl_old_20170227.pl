#!/usr/bin/perl -w
use strict;
use Getopt::Long;

# output line content : prot_name 	cx	 			cy  			cz	 			q_str		TM1		TM2		 Lg			Ls		Lcov	Predicted Binding Residue Index (Start From 1);
# e.g., 								3REUA_BS01 	15.12477 	15.11108 	59.67531 	0.59 		0.44 	0.84 	 0.93 	0.74	0.93 	321 323 329 330 331 334 336 471 472 473 474 519 522

# input
my $system    = $^O;
my $query_pdb				=	"";				# the query pdb file absolute path
my $jsd_score   		=	"";				# the corresponding jsd_score file of the query pdb [Absolute Path]
my $libbsr					=	"";				# the BSITES.bsr file absolute path
my $libsrc					=	"";				# the BSITES.center file absolute path
my $recseqfile			= ""; 			# the BSITES.fasta file absolute path
my $dir_pocket_lib	=	"";				#	the pocket folder absolute path
my $tmsite					=	"";				# the tmsite cpp runnable program absolute path
my $NWalign_simple	= ""; 			# the NWalign_simple cpp runnable program absolute path
my $stride					= "";				# the stride cpp runnable program absolute path
my $idcut						=	"";				# the sequence identity cutoff value
#my $query_pdb			=	"/data/junh/delete/2XTIB.pdb";
#my $jsd_score   		=	"/data/junh/delete/AHA_JSD_SCORE";
#my $libbsr					=	"/data/junh/library/BPOCKET/BSITES.bsr";		# the BSITES.bsr file absolute path
#my $libsrc					=	"/data/junh/library/BPOCKET/BSITES.center";	# the BSITES.center file absolute path
#my $recseqfile			= "/data/junh/library/BPOCKET/BSITES.fasta"; 	# the BSITES.fasta file absolute path
#my $dir_pocket_lib	=	"/data/junh/library/BPOCKET/pocket";				#	the pocket folder absolute path
#my $tmsite					=	"/data/junh/software/I-TASSER/I-TASSER5.0/COACH/bin/tmsite";	# the tmsite cpp runnable program absolute path
#my $NWalign_simple	= "/data/junh/software/I-TASSER/I-TASSER5.0/COACH/bin/NWalign_simple"; # the NWalign_simple cpp runnable program absolute path
#my $stride					= "/data/junh/software/I-TASSER/I-TASSER5.0/bin/stride";	# the stride cpp runnable program absolute path
#my $idcut					=	0.9;

# output
my $query_mod						= "";		# just a name, which is used for save the copy query_pdb with secondary information
my $tmsite_out_put			=	""; 	# save the &template_search function output, which is based on tmsite
my $final_templates			=	"";		# save the optimal template list, which are selected based on Qstr
#my $query_mod						= "/data/junh/delete/2XTIB.pdb_mod";	# just a name, which is used for save the copy query_pdb with secondary information
#my $tmsite_out_put			=	"/data/junh/delete/2XTIB.tmsite.out"; # save the &template_search function output, which is based on tmsite
#my $final_templates			=	"/data/junh/delete/2XTIB.tmsite.final_templ";		# save the optimal template list, which are selected based on Qstr

my $active_ligtypes			= ""; 	# the active ligand types, e.g., :ATP:ADP:...:CA, or "ALL"

##############################################################
### input parameters
unless (lc($system) eq "linux")
{
    printf("Your operating system $system is unsupported at this time\n");
    printf("Currently only Linux is supported\n");
    exit();
}
GetOptions('query_pdb:s' => \$query_pdb, 'jsd_score:s' => \$jsd_score, 'libbsr:s' => \$libbsr, 'libsrc:s' => \$libsrc, 'recseqfile:s' => \$recseqfile,  'dir_pocket_lib:s' => \$dir_pocket_lib,  'tmsite:s' => \$tmsite,  'NWalign_simple:s' => \$NWalign_simple,  'stride:s' => \$stride,  'idcut:s' => \$idcut,  'query_mod:s' => \$query_mod, 'tmsite_out_put:s' => \$tmsite_out_put, 'final_templates:s' => \$final_templates, 'active_ligtypes:s' => \$active_ligtypes);

if(!$query_pdb || !$jsd_score    || !$libbsr || !$libsrc || !$recseqfile || !$dir_pocket_lib || !$tmsite || !$NWalign_simple || !$stride || !$idcut || !$query_mod || !$tmsite_out_put || !$final_templates)
{
    print "\nVotedSelectLBS usage:\nVotedSelectLBS.pl arguments\n";
    print "====================\n";
    print "Mandatory arguments:\n";
    print "====================\n";
    print "-query_pdb query_pdb 						(IN)(The query pdb file's absolute path)\n";
    print "-jsd_score jsd_score 						(IN)(the corresponding jsd_score file of the query pdb file [Absolute path])\n";
    print "-libbsr libbsr										(IN)(the BSITES.bsr file absolute path, which is one file in the library)\n";
    print "-libsrc libsrc										(IN)(the BSITES.center file absolute path, which is one file in the library)\n";
		print "-recseqfile recseqfile						(IN)(the BSITES.fasta file absolute path, which is one file in the library)\n";
		print "-dir_pocket_lib dir_pocket_lib 	(IN)(the pocket folder absolute path, which is one folder in the library)\n";
		print "-tmsite tmsite 									(IN)(the tmsite exe file absolute path)\n";
		print "-NWalign_simple NWalign_simple 	(IN)(the NWalign_simple exe file absolute path)\n";
		print "-stride stride 									(IN)(the stride exe file absolute path)\n";
		print "-idcut idcut 										(IN)(The sequence identity cutoff, which is used for searching template receptors(or proteins))\n";
  	print "-query_mod query_mod 						(OUT)(To save the the query_pdb combine the secondary structure information)\n";
    print "-tmsite_out_put tmsite_out_put 	(OUT)(To save the tmsite output)\n";
    print "-final_templates final_templates (OUT)(TO save the last selected template receptor information)\n";
    print "-active_ligtypes active_ligtypes (IN)(The active ligand types e.g., :ATP:ADP:...:CA, or \"ALL\", default is \"ALL\")\n";
    exit();
}

if (!$active_ligtypes)
{
	$active_ligtypes = "ALL";
}

########################################################################################
### Calculating the protein secondary structure information based on query_pdb,
### then add it in the end of the corresponding line 
&make_ss($query_pdb, $query_mod);

########################################################################################
#### Global Parameter 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Step 0: parameters set ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#Set program parameters here
my $nTemplates     = 1;           #how many top templates to select
my $nTemplates1    = 10;          #if not enough templates satisfying tmscoreCutoff, how many top templates to use
my $no_res_cut     = 5;           #minimum number of residues in pocket for using TM-align >=5
my $vote_cut       = 0.25;        #vote for inferring final binding (just for $saveBsites_dat)
my $cluster_cutoff = 4.0;         #cutoff for average linkage clustering of superposed template ligands
my $quality_cut    = 0.57;        #cutoff for overal quality [Qstr cutoff]

my %Qtemplate=();
my %AA=(
        'ALA'=>'A', 'ARG'=>'R', 'ASN'=>'N', 'ASP'=>'D', 'CYS'=>'C', 'GLN'=>'Q', 'GLU'=>'E', 'GLY'=>'G',
        'HIS'=>'H', 'ILE'=>'I', 'LEU'=>'L', 'LYS'=>'K', 'MET'=>'M', 'PHE'=>'F', 'PRO'=>'P', 'SER'=>'S',
        'THR'=>'T', 'TRP'=>'W', 'TYR'=>'Y', 'VAL'=>'V', 'ASX'=>'N', 'GLX'=>'Q', 'UNK'=>'G',
        'A'=>'ALA', 'R'=>'ARG', 'N'=>'ASN', 'D'=>'ASP', 'C'=>'CYS', 'Q'=>'GLN', 'E'=>'GLU', 'G'=>'GLY',
        'H'=>'HIS', 'I'=>'ILE', 'L'=>'LEU', 'K'=>'LYS', 'M'=>'MET', 'F'=>'PHE', 'P'=>'PRO', 'S'=>'SER',
        'T'=>'THR', 'W'=>'TRP', 'Y'=>'TYR', 'V'=>'VAL', 'B'=>'ASX', 'Z'=>'GLX', 'X'=>'UNK');

##################################################################################
## Load BSITES.bsr file information Library Information
my %bsligname=();
my %bslib=(); 		#all binding sites for all templates in the library
open(LIB, "$libbsr");
while(my $line = <LIB>)
{    chomp($line);

    if(substr($line, 11, 1) eq 'P')
    {
			last;
    }
    if($line=~/(\S+)\s+\:(.+)\:(\S+)\:(\d+)\:(\S+)/)
    {
			my $rec =$1;
			my $ligname=$2;
			my $bsno=$3;
			my $bres=$5;
			my $site=$rec . "_" . $bsno;
			$bslib{$site}=$bres;
			$ligname =~ s/\s+//g;
			$bsligname{$site}=$ligname;
    }
}
close(LIB);

#############################################################################
## Load BSITES.center file information
my %bslibc=(); 		#center
open(LIB, "$libsrc");
while(my $line = <LIB>)
{
    chomp($line);
    if($line=~/(\S+):(\S+)/)
    {
			$bslibc{$1}=$2;
    }
}
close(LIB);

##############################################################################
### Load receptor sequence from BSITES.fasta
my %bslibd=(); 		#date
my %recseq=();
open(REC, "$recseqfile");
while(my $line = <REC>)
{
    chomp($line);
    if($line =~ /^>(\S+)/)
    {
			my $rec=$1;
			$line = <REC>;
			chomp($line);
			$recseq{$rec}=$line;
    }
}
close(REC);

##############################################################################
### Load query structure for only once
my $queryseq=&getfasta($query_mod);
my %ss=();
&load_ss($query_mod);
my %xyz=&load_Ca($query_mod);

############### run ConCavity to extract fragments from query structure ###################
## this part is skipped as we can not include ConCavity into the package
## due to copyright issue
#########

### May be you can do it


###########################################################################################
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Step 1: TMalign search ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#=== Step 1.1: TMalign search on template pocket library --->
if(-s "$tmsite_out_put")
{
    printf "$tmsite_out_put has been done!\n";
}
else
{
    printf "Running TM-align to search library, with sequence identity cutoff ...\n";
    &template_search($dir_pocket_lib, $query_mod, $tmsite_out_put);
}

###########################################################################################
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Step 2: collect templates  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
my $q_cut=$quality_cut;

my %quality=();
my %pbsr=();
my %pcenter=();
my $relieve_flag=0;

print "select templates...\n";
&select_templates($tmsite_out_put);

my $n_selected = keys %quality;
if($n_selected < $nTemplates)
{
    %quality=();
    $relieve_flag=1;
    print "selected number of templates are too small ($n_selected), use top $nTemplates1\n";        	
    &select_templates1($tmsite_out_put);
} 

#########################################################################################################
#### Selected the optimal template    
#sort templates by average score
my @keys = reverse sort{$quality{$a} <=> $quality{$b}} keys %quality;
$n_selected=@keys;
if($n_selected<1)
{
    die "No templates selected!\n";
}

my %final_rec=();
open(FOUT, ">$final_templates");
foreach my $k(@keys)
{            	
    #for the selected templates, if there are templates with quality >0.85, then only use good templates
    my @residues=split(/,/, $pbsr{$k});
    print FOUT "$k $pcenter{$k} @residues\n";
    
}
close(FOUT);

print "Done!\n";



###########################################################################################################
### Sub function procedure

sub load_ss
{
    my ($pdbfile)=@_;
	
    open(QUE, "<$pdbfile") or die "$pdbfile file is missed!\n";
    my @res_no=();
    my $i=0;
    while(my $line = <QUE>)
    {
				if($line =~ /^ATOM/)
				{
				    my $alt=substr($line, 16, 1); #alterate for atom
				    if($alt eq " " || $alt eq "A"|| $alt eq "1")
				    {
								my $str=substr($line, 12, 2); 		
								if($str =~ /H/g)
								{
								    next;
								}
								
								my $n = substr($line, 22, 4);  $n =~ s/\s+//;
								$res_no[$i]=$n;
								$i++;
						
								if(!exists $ss{$n})
								{
								    $ss{$n}=substr($line, 79, 1);
								}
				    }
				}
    }
    close(QUE);
}

sub load_Ca
{
    my ($pdbfile)=@_;
	
    open(QUE, "<$pdbfile") or die "$pdbfile file is missed!\n";
    my %xyz=();
    my $i=0;
    my %resatoms=();
    
    while(my $line = <QUE>)
    {
				if($line =~ /^ATOM/)
				{
				    my $atom_name=substr($line, 12, 4);
				    if($atom_name eq ' CA ')
				    {		    
								my $res_no = substr($line, 22, 5); $res_no =~ s/\s+//g;
								my $check  = $res_no .  $atom_name;
								if(!exists $resatoms{$check}) #ignore alternative location of atoms
								{
								    $resatoms{$check}=1;
						
								    $xyz{$res_no, 1} = substr($line, 30, 8);
								    $xyz{$res_no, 2} = substr($line, 38, 8);
								    $xyz{$res_no, 3} = substr($line, 46, 8);
								}
				    }
				}
    }
    close(QUE);

    return %xyz;
}

sub template_search
{
    my ($dir_pocket_lib, $query, $tmsite_out_put) = @_;
    my $seqid="";
    my %chains=();
    my @keys= keys %bslib;
    open(FRES, ">$tmsite_out_put");

    foreach my $rec(@keys)
    {
    		# junh start
				my $ligname = $bsligname{$rec};
				if (!($active_ligtypes eq "ALL"))
				{
					if (!($active_ligtypes =~ /:$ligname:/))
					{
						next;
					}
				}
				printf "$ligname aha $active_ligtypes\n";
				# junh end
    		
				my $chain=substr($rec, 0, 5);	
				if(!exists $chains{$chain})
				{	    
						####  sequence identity cutoff 
				    my $seq1=$recseq{$chain};  
				    $seqid=`$NWalign_simple $seq1 $queryseq 3`;
						$chains{$chain}=$seqid;
						if($seqid>$idcut)
						{
						    next;
						}
				}
				else
				{
				    if($chains{$chain}>$idcut)
				    {
								next;
				    }
				}
				
				my $line=$bslib{$rec};		
				my @pocres=split(/,/, $line);
				my $nres=$#pocres;
				my $firstRes=sprintf "%d", $pocres[0];
				my $lastRes=sprintf "%d", $pocres[$nres];

				if(!-s "$dir_pocket_lib/$rec.pdb") {die "$dir_pocket_lib/$rec.pdb is missed\n";}
				if(($lastRes-$firstRes)<=$no_res_cut) 
				{
	    			#check the pocket file to see if it was extended
	    			my $tseq=&getfasta("$dir_pocket_lib/$rec.pdb");
	    			if(length $tseq<=$no_res_cut)
	    			{
							next;
	    			}
				}	    
				print FRES "$rec";
	    
				my $cmd="$tmsite -B $dir_pocket_lib/$rec.pdb -A $query -rB $line";
				my @rst=`$cmd`;
				my $i=0;
				my $flag=0;
				my $predBSR="";
				my $Lg=0;
				my $Ls=0;
				my $Lcov=0;
				for($i=0; $i<=$#rst; $i++)
				{
	    			my $r=$rst[$i];
            if($r =~ /^predicted BSR:(\S+)/)
            {
                $predBSR=$1;
            }
            if($r =~ /^Lg=(\S+)/)
            {
                $Lg=$1;
            }
            if($r =~ /^Ls=(\S+)/)
            {
                $Ls=$1;
            }
           	if($r =~ /^Lcov=(\S+)/)
            {
                $Lcov=$1;
            }

	    			if($r =~ /^TM-score=(\S+)\s+/)
	    			{
								printf FRES ":%6.5f", $1;
	    			}
	    			if($rst[$i]=~/\s+1\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/)
	    			{	
								printf FRES ":%.5f,%.5f,%.5f,%.5f", $1,$2,$3,$4;	
	    			}
	    			if($rst[$i]=~/\s+2\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/)
	    			{
								printf FRES ",%.5f,%.5f,%.5f,%.5f", $1,$2,$3,$4;
	    			}
	    			if($rst[$i]=~/\s+3\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/)
	    			{
								printf FRES ",%.5f,%.5f,%.5f,%.5f", $1,$2,$3,$4;
								$flag=1;
								last;
	    			}
				}		
				print FRES ":$Lg:$Ls:$Lcov:$predBSR";
        if($flag==0)
        {
            print "wrong running of TM-align for $rec\n";
            print FRES "ERROR";
        }

				print FRES "\n";
    }
    close(FRES);
}

sub select_templates
{
    my ($filename)=@_;   

    open(FIN, "$jsd_score") or die "No jsdscore\n";
    my %JSD=();
    while(my $line = <FIN>)
    {
        if($line =~ /(\d+)+\s+\S+\s+(\S+)/)
        {
            my $res=$1+1;
            my $score=$2;
            $JSD{$res}=$score;
        }
    }
    close(FIN);

    my @tx=();
    my @ty=();
    my @tz=();
    my @tatom=();
    my %t_res_no=();
    my @bs_template=();
    my $n=0;

    open(FIN, $filename) or die "$filename is missed!\n";    
    while(my $line1 = <FIN>)
    {
				chomp($line1);
        if($line1 =~ /ERROR/)
        {
            next;
        }

				if($line1 =~ /(\S+)/)
				{	   	    
	    		my @inf=split(/:/, $line1, -1);
	    		my $site=$inf[0];
	    		
	    		my $pdb=substr($site, 0, 5);
	    		#if($pdb ne "3luoA") {next;}
	    		my $bres=$bslib{$site};    	   

	    		my $score1=$inf[1]; #tmscore normlized by query
	    		my $score2=$inf[2]; #tmscore normlized by template
	    		my @matrix=split(/,/, $inf[3]);
	    		my @rot=();
	    		my @tra=();
	    		$tra[0]    = $matrix[0];
	    		$rot[0][0] = $matrix[1];
	    		$rot[0][1] = $matrix[2];
	    		$rot[0][2] = $matrix[3];

			    $tra[1]    = $matrix[4];
			    $rot[1][0] = $matrix[5];
			    $rot[1][1] = $matrix[6];
			    $rot[1][2] = $matrix[7];
		
			    $tra[2]    = $matrix[8];
			    $rot[2][0] = $matrix[9];
			    $rot[2][1] = $matrix[10];
			    $rot[2][2] = $matrix[11];

			    my $Lg      = $inf[4];
			    my $Ls      = $inf[5];
			    my $Lcov    = $inf[6];
			    my $predBSR = $inf[7];

			    if($predBSR !~ /\d+/) 
			    {
							#print "ignore $site $predBSR\n";
							next;
			    }
			    my @pred=split(/,/, $predBSR);
	    		my $cons=0;
	    		foreach my $p(@pred)
	    		{
							if(!exists $JSD{$p})
							{
		    					print "wrong res $p\n";
		    					next;
							}
							$cons += $JSD{$p};
	    		}
	    		if(@pred>0)
	    		{
							$cons=$cons/@pred;
	    		}

	    		my $tm=2.0*($score1*$score2)/($score1+$score2);
					my $q = 2.0/(1.0 + exp( -( $Lcov*(0.4*$Lg+0.3*$Ls+0.2*$cons) +  $tm)**2) )-1.0;
	    		$Qtemplate{$site}=$q;
    
	    		if($q>$q_cut)
	    		{   
							my @pBSR=split(/,/, $predBSR);
							if(!exists $bslibc{$site})
							{
							    die "$site\n";
							}
						
							my $x=0; my $y=0; my $z=0; my $wrong=0;
							foreach my $b(@pBSR)
							{
							    if(!exists $xyz{$b, 1})
							    {
											print "wrong residue $b\n";
											$wrong=1;
											last;
							    }
					
							    $x += $xyz{$b, 1};
							    $y += $xyz{$b, 2};
							    $z += $xyz{$b, 3};
							}
							$x = $x/@pBSR;
							$y = $y/@pBSR;
							$z = $z/@pBSR;
							
							if($wrong==1)
							{
		    					next;
							}

							#my $rx=$rot[0][0]*$tc[0]+$rot[0][1]*$tc[1]+$rot[0][2]*$tc[2]+$tra[0];
							#my $ry=$rot[1][0]*$tc[0]+$rot[1][1]*$tc[1]+$rot[1][2]*$tc[2]+$tra[1];
							#my $rz=$rot[2][0]*$tc[0]+$rot[2][1]*$tc[1]+$rot[2][2]*$tc[2]+$tra[2];
	    
							$quality{$site} = $q;
							$pbsr{$site}    = $predBSR;
							#$pcenter{$site} = sprintf "%.5f %.5f %.5f %.2f %.2f %.2f %.2f %.2f %.2f", $rx, $ry, $rz, $q, $score1, $score2, $Lg, $Ls, $Lcov;
							$pcenter{$site} = sprintf "%.5f %.5f %.5f %.2f %.2f %.2f %.2f %.2f %.2f", $x, $y, $z, $q, $score1, $score2, $Lg, $Ls, $Lcov;
	    		}
				}
    }
    close(FIN);
}


sub select_templates1
{
    my ($filename)=@_;

    my @tx=();
    my @ty=();
    my @tz=();
    my @tatom=();
    my %t_res_no=();
    my @bs_template=();
    my $n=0;

    my @allt = sort {$Qtemplate{$b} <=> $Qtemplate{$a}} keys %Qtemplate;


    my %topT=();
    for(my $i=0; $i<$nTemplates1; $i++)
    {
	$topT{$allt[$i]}=1;
    }

    open(FIN, $filename) or die "$filename is missed!\n";    
    while(my $line1 = <FIN>)
    {
	chomp($line1);
        if($line1 =~ /ERROR/)
        {
            next;
        }

	if($line1 =~ /(\S+)/)
	{	    
	    my @inf=split(/:/, $line1);

	    my $site=$inf[0];
	    #if($bslibd{$site} == 1)
	    #{
		#next;
	    #}

	    if(!exists $topT{$site})
	    {
		next;
	    }
	    my $pdb=substr($site, 0, 5);
	    #if($pdb ne "3luoA") {next;}
	    my $bres=$bslib{$site};    	   

	    my $score1=$inf[1]; #tmscore normlized by query
	    my $score2=$inf[2]; #tmscore normlized by template
	    my @matrix=split(/,/, $inf[3]);
	    my @rot=();
	    my @tra=();
	    $tra[0]    = $matrix[0];
	    $rot[0][0] = $matrix[1];
	    $rot[0][1] = $matrix[2];
	    $rot[0][2] = $matrix[3];

	    $tra[1]    = $matrix[4];
	    $rot[1][0] = $matrix[5];
	    $rot[1][1] = $matrix[6];
	    $rot[1][2] = $matrix[7];

	    $tra[2]    = $matrix[8];
	    $rot[2][0] = $matrix[9];
	    $rot[2][1] = $matrix[10];
	    $rot[2][2] = $matrix[11];

	    my $Lg      = $inf[4];
	    my $Ls      = $inf[5];
	    my $Lcov    = $inf[6];
	    my $predBSR = $inf[7];

	    my $q=$Qtemplate{$site};   


	    my @pBSR=split(/,/, $predBSR);
	    
	    if(!exists $bslibc{$site})
	    {
		die "$site\n";
	    }
	    #my @tc=split(/,/, $bslibc{$site});
	    #my $rx=$rot[0][0]*$tc[0]+$rot[0][1]*$tc[1]+$rot[0][2]*$tc[2]+$tra[0];
	    #my $ry=$rot[1][0]*$tc[0]+$rot[1][1]*$tc[1]+$rot[1][2]*$tc[2]+$tra[1];
	    #my $rz=$rot[2][0]*$tc[0]+$rot[2][1]*$tc[1]+$rot[2][2]*$tc[2]+$tra[2];


	    my $x=0; my $y=0; my $z=0; my $wrong=0;
	    foreach my $b(@pBSR)
	    {
		if(!exists $xyz{$b, 1})
		{
		    print "wrong residue $b\n";
		    $wrong=1;
		    last;
		}
		
		$x += $xyz{$b, 1};
		$y += $xyz{$b, 2};
		$z += $xyz{$b, 3};
	    }
	    $x = $x/@pBSR;
	    $y = $y/@pBSR;
	    $z = $z/@pBSR;
	    
	    if($wrong==1)
	    {
		next;
	    }

	    
	    $quality{$site} = $q;
	    $pbsr{$site}    = $predBSR;
	    #$pcenter{$site} = sprintf "%.5f %.5f %.5f %.2f %.2f %.2f %.2f %.2f %.2f", $rx, $ry, $rz, $q, $score1, $score2, $Lg, $Ls, $Lcov;	    
	    $pcenter{$site} = sprintf "%.5f %.5f %.5f %.2f %.2f %.2f %.2f %.2f %.2f", $x, $y, $z, $q, $score1, $score2, $Lg, $Ls, $Lcov;
	}
    }
    close(FIN);
}

sub getfasta
{
    my $seq="";
    my ($pdb)=@_;
    open(FPDB, $pdb) or die "$pdb is missed!\n";
    my %resatoms=();
    while(my $line = <FPDB>)
    {
	if($line =~ /^ATOM/i)
	{
            my $res_name  = substr($line, 17, 3);  
            my $res_no    = substr($line, 22, 5);
            my $check     = $res_no .  substr($line, 12, 4); #atom

	    if(!exists $resatoms{$check}) ##check for alternative position atoms
	    {
		$resatoms{$check}=1;

		my $atom_name=substr($line, 12, 4);
		if($atom_name eq ' CA ')
		{
		    $seq = $seq. $AA{$res_name};
		}		
	    }
	}
    }
    close(FPDB);

    return $seq;
}

sub make_ss
{
    my ($query_pdb, $query_mod)=@_;
    
    my %HEC=('H'=>'H', 'G'=>'H', 'I'=>'H', 'B'=>'E', 'b'=>'E', 'E'=>'E', 'T'=>'C', 'C'=>'C');
    my @rec=();
    
    #generate SS with stride if the model
    open(FREC, "<$query_pdb");
    while(my $line1 = <FREC>)
    {
        chomp($line1);
        push(@rec, $line1);
    }
    close(FREC);

    my %ss=();
    my @rst=`$stride $query_pdb`;
    foreach my $r(@rst)
    {
        if($r =~ /^ASG/)
        {
            my $resno=sprintf "%d", substr($r, 11, 4); #original residue number
            my $s=$HEC{substr($r, 24, 1)};
            $ss{$resno}=$s;
        }
    }

    open(FREC, ">$query_mod"); 
    foreach my $r(@rec)
    {
        if($r =~ /^ATOM/)
        {
            my $resno=sprintf "%d", substr($r, 22, 4);
            my $s="C";
            if(exists $ss{$resno})
            {
                $s=$ss{$resno};
            }
            my $len=length $r;
            my $r1=substr($r, 0, $len);
            for(my $i=$len; $i<80; $i++)
            {
                $r1 .= " ";
            }

            substr($r1, 79, 1)= sprintf "%1s", $s;
            substr($r1, 55, 1) =sprintf "%1s", $s;

            my $atom=substr($r1, 12, 2);
            if($atom =~ /H/)
            {
                next;
            }
            print FREC "$r1\n";
        }
        else
        {
            print FREC "$r\n";
        }
    }
    close(FREC);
}









